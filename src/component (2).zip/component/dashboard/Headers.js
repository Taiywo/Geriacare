import React from "react";
import {
  UploadOutlined,
  UserOutlined,
  VideoCameraOutlined,
} from "@ant-design/icons";
import { Layout, Menu, theme, notification } from "antd";
import bellIcon from "../../Assets/images/bell.svg";
import profile from "../../Assets/images/Account circle.svg";
import bed from "../../Assets/images/mdi_bed.svg";
import board from "../../Assets/images/ClipboardListOutline.svg";
import { motion } from "framer-motion";
const { Header, Content, Footer, Sider } = Layout;
const Headers = () => {
  const {
    token: { colorBgContainer },
  } = theme.useToken();

  const [api] = notification.useNotification();
  const openNotification = () => {
    api.open({
      message: (
        <motion.div
          className="font-[caveat-brush]"
          initial={{ opacity: 0 }}
          animate={{ opacity: 2 }}
          transition={{ duration: 1 }}
        >
          <p>Notification Title</p>
        </motion.div>
      ),
      description:
        "I will never close automatically. This is a purposely very very long description that has many many characters and words.",
      duration: 0,
    });
  };
  const topCards = [
    {
      patientState: "Number of Elderly",
      patientNumber: "1",
      image: profile,
    },
    {
      patientState: "Number of Visits",
      patientNumber: "5",
      image: bed,
    },
    {
      patientState: "Active Subscription",
      patientNumber: "2",
      image: board,
    },
  ];

  return (
    <Layout className="min-h-screen w-full ">
      <Sider
        breakpoint="lg"
        collapsedWidth="0"
        onBreakpoint={(broken) => {
          console.log(broken);
        }}
        onCollapse={(collapsed, type) => {
          console.log(collapsed, type);
        }}
      >
        <div className="demo-logo-vertical" />
        <Menu
          theme="dark"
          mode="inline"
          defaultSelectedKeys={["4"]}
          items={[
            UserOutlined,
            VideoCameraOutlined,
            UploadOutlined,
            UserOutlined,
          ].map((icon, index) => ({
            key: String(index + 1),
            icon: React.createElement(icon),
            label: `nav ${index + 1}`,
          }))}
        />
      </Sider>
      <Layout>
        <Header
          style={{
            padding: 0,
            background: colorBgContainer,
          }}
        >
          <div className="flex items-center font-[poppins-regular] justify-between px-24">
            <p className="font-[poppins-regular] text-[0.7rem] mr-[0.5rem] sm:mr-[0.5rem] md:text-[1.1rem]">
              Hi User, Welcome
            </p>
            <div className="flex font-[poppins-regular] items-center justify-center w-15 h-15">
              <div
                className="bg-white rounded-full shadow-md font-[poppins-regular] flex items-center justify-center cursor-pointer w-8 h-8"
                onClick={openNotification}
              >
                <img src={bellIcon} alt="bell Icon" className="w-6 h-6" />
              </div>
            </div>
          </div>
        </Header>
        <Content
          style={{
            margin: "24px 16px 0",
          }}
        >
          <div
            style={{
              padding: 48,
              minHeight: 360,
              background: colorBgContainer,
              height: "100%",
              width: "100%",
              display: "flex",
              flexDirection: "column",
              // justifyContent: "center",
              // alignItems:"center"
              gap: "56px",
            }}
          >
            <div className=" flex item-center justify-between gap-[116px]">
              {topCards.map((card, index) => {
                return (
                  <div
                    key={index}
                    className="h-[8rem] w-[20rem] bg-[#41B282] px-[2rem] justify-center rounded-sm flex flex-col  shadow-md gap-[1rem]"
                  >
                    <h1 className="font-regular  text-white font-[poppins-regular] text-[1.5rem] font-bold">
                      {card.patientState}
                    </h1>
                    <div className="flex justify-between">
                      <h1 className="font-bold text-center text-[2rem] justify-between text-white font-[poppins-regular]">
                        {card.patientNumber}
                      </h1>
                      <img src={card.image} alt="card-icon" />
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="border-[0.4px] rounded-md border-[#a7a2a2] shadow-md h-[11rem] w-[100%] p-5">
              <h1 className=" font-[poppins-bold] text-[2.2rem] uppercase text-[#9a9a9a]">
                Recent Visits
              </h1>
              <hr />
              <p className="mt-10 cursor-pointer text-red-500 underline text-[1rem]">
                No Visits Yet
              </p>
            </div>
            <div className="border-[0.4px] rounded-md border-[#a7a2a2] shadow-md h-[11rem] w-[100%] p-5">
              <h1 className=" font-[poppins-bold] text-[2.2rem] uppercase text-[#9a9a9a]">
                My Subscriptions
              </h1>
              <hr />
              <div className="border-[0.4px] border-[#a7a2a2]">
                <div>
                  <span className=" font-semibold px-[20] py-[24px] inline-block border-r-2">
                    Patient Name
                  </span>
                  <span className=" font-semibold px-[20] py-[24px] inline-block">
                    Service Plan
                  </span>
                  <span className=" font-semibold px-[20] py-[24px] inline-block">
                    Visits Remaining
                  </span>
                  <span className=" font-semibold px-[20] py-[24px] inline-block">
                    Duration
                  </span>
                  <span className=" font-semibold px-[20] py-[24px] inline-block">
                    Expiration Date
                  </span>
                  <span className=" font-semibold px-[20] py-[24px] inline-block">
                    Status
                  </span>
                </div>
                <div></div>
              </div>
            </div>
          </div>
        </Content>
        <Footer
          style={{
            textAlign: "center",
          }}
        >
          Ant Design ©2023 Created by Ant UED
        </Footer>
      </Layout>
    </Layout>
  );
};
export default Headers;
