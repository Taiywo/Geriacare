import React from "react";
import { Layout } from "antd";

const { Content } = Layout;

const MainContent = () => {
  return <Content>{/* Add main content */}</Content>;
};

export default MainContent;
