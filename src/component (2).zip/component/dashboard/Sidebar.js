import React from "react";
import { Layout, Menu } from "antd";

const { Sider } = Layout;

const Sidebar = () => {
  return (
    <Sider width={200}>
      <Menu mode="vertical">{["Menu 1", "Menu 2", "Menu 3", "Menu 4"]}</Menu>
    </Sider>
  );
};

export default Sidebar;
